/*
 * Name : Rennie Kipchirchir
 * Project: Spaceship Simulator
 * File: MyMap.java
 * Date modified: 10/05/23
 * 
 * This file contains MyMap class. It is inform of a circle. The map contians
 * other items drawn in it. 
 */


import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.*;

//class that creates a circle drawing using the drawing canvas interface
class CircleCanvas implements DrawingCanvas {
    /* draw 
     * parameters include a 2d graphics and dimesnions of drawing canvas
     * returns nothing
    */
    public void draw(Graphics2D g, Dimension canvasSize) {
        //add padding from edge of container
        int diameter = Math.min(canvasSize.width, canvasSize.height) - Global.PADDING;

        //centers the circle in the drawing panel
        int divisor = 2;
        int x = (canvasSize.width - diameter) / divisor;
        int y = (canvasSize.height - diameter) / divisor;

        g.drawOval(x, y, diameter, diameter);
    }
}

//SpaceShipCanvas Class that draws a spaceship
class SpaceShipCanvas implements DrawingCanvas {

    private double xOffset = 3;
    private double yOffset = 3;
    /* draw 
     * parameters include a 2d graphics and dimesnions of drawing canvas
     * returns nothing
    */
    public void draw(Graphics2D g, Dimension canvasSize) {

        int baseSize = Math.min(canvasSize.width, canvasSize.height);

        //length of spaceship landing base
        int spaceshipLength = baseSize / Global.SCALE; 
        
        //height for the main body for the spaceship (taller)
        int spaceshipHeight = spaceshipLength / 2;

        //height of the side compartments for a spaceship(shorter sides)
        int smallTriangleHeight = spaceshipHeight / 3; 

        int centerX = (int) (canvasSize.height / xOffset);
        int centerY = (int) (canvasSize.width / yOffset);
        int x_divisor = 2;

        int[] xPoints = {
            centerX + spaceshipHeight / x_divisor,//base level
            //top of left compartment
            centerX + spaceshipHeight / x_divisor - smallTriangleHeight,

            centerX - spaceshipHeight / x_divisor,//height of ship

            //top of right compartment
            centerX + spaceshipHeight / x_divisor - smallTriangleHeight,
            
            centerX + spaceshipHeight / x_divisor, //base level
            centerX + spaceshipHeight / x_divisor, //bottom of right
            centerX + spaceshipHeight / x_divisor //bottom of left
        };

        int[] yPoints = {
            centerY - spaceshipLength / x_divisor, //most left vertex
            centerY - spaceshipLength / 4, //base of left side
            centerY, //top of main compartment
            centerY + spaceshipLength / 4, //base of right side
            centerY + spaceshipLength / x_divisor, //most right vertex
            centerY + spaceshipLength / 6, //bottom of right side
            centerY - spaceshipLength / 6 //bottom of left side
        };

        g.fillPolygon(xPoints, yPoints, 7);
    }

    public void updateLocation() {
        Random rand = new Random();

        double minX = 1.5;
        double maxX = 4.5;

        xOffset =  minX + (maxX - minX) * rand.nextDouble();
        yOffset =  minX + (maxX - minX) * rand.nextDouble();
    }
}

//planetCanvas Class that draws a DrawingCanvas
class PlanetCanvas implements DrawingCanvas {
    private double xOffset = 1.5;
    private double yOffset = 1.5;
    
    /* draw 
     * parameters include a 2d graphics and dimesnions of drawing canvas
     * returns nothing
    */
    public void draw(Graphics2D g, Dimension canvasSize) {
        int diameter = (Math.min(canvasSize.width, 
                        canvasSize.height) / Global.SCALE); //planet diameter
        
        //calculating x and y coordinate of plane
        int x = (int) ((canvasSize.width - diameter) / xOffset);
        int y = (int) ((canvasSize.height - diameter) / yOffset);

        g.setColor(Color.blue);
        g.fillOval(x, y, diameter, diameter);
    }

    //updates location of planet on map when called
    public void updateLocation() {
        Random rand = new Random();

        double minX = 1.5;
        double maxX = 4.5;

        //limits random numbers to values between 1.5 and 4.5
        xOffset =  minX + (maxX - minX) * rand.nextDouble();
        yOffset=  minX + (maxX - minX) * rand.nextDouble();
    }
}

//pointer hand to simulate a rotating radar
class PointerCanvas implements DrawingCanvas {

    private double pointerAngle = 0; //variable to track angle of rotation

    /* draw 
     * parameters include a 2d graphics and dimesnions of drawing canvas
     * returns nothing
    */
    public void draw(Graphics2D g, Dimension canvasSize) {

        //x and y coordinates and diameterof the circle map
        int diameter = Math.min(canvasSize.width, canvasSize.height) - Global.PADDING;
        int x = (canvasSize.width - diameter) / 2;
        int y = (canvasSize.height - diameter) / 2;
        

        //center of the circle map should be starting point for pointer(x + r)
        int centerX = x + diameter / 2;
        int centerY = y + diameter / 2;

        //end of the circle map using the formula x = r * cos(angle)
        //using angles so that it is recalculated to simulate rotation of ptr
        int endX = centerX + (int) (diameter / 2 * Math.cos(pointerAngle - Math.PI / 2));
        int endY = centerY + (int) (diameter / 2 * Math.sin(pointerAngle - Math.PI / 2));
        
        g.setColor(Color.green);
        g.drawLine(centerX, centerY, endX, endY);
    }

    /* updatePointer
     * parameters none
     * returns nothing
     * The function updates the pointer angle every time it is called
    */
    public void updatePointer() {
        pointerAngle += Math.toRadians(2); //update angle by 2 degrees
    }
}

/*class that implements the rotation aspect of the pointer */
class PointerUpdateListener implements ActionListener {
    
    private PointerCanvas pointerCanvas;
    private MyMap myMap;

    /* PointerUpdateListener
     * parameters include the pointer hand and the parent container i.e map
     * returns nothing
     * constructor for the class
    */
    public PointerUpdateListener(PointerCanvas pCanvas, MyMap map) {
        this.pointerCanvas = pCanvas;
        this.myMap = map;
    }

    /*implements the rotation action but relies on PointerCanvas class fn()
    */
    public void actionPerformed(ActionEvent e) {
        pointerCanvas.updatePointer();
        myMap.repaint(); //redraw the entire map
    }
}


//asteroid class that draws an asteroid
class AsteroidCanvas implements DrawingCanvas {
    private double xOffset = 1.5;;
    private double yOffset = 4.5;

    /* draw 
     * parameters include a 2d graphics and dimesnions of drawing canvas
     * returns nothing
    */
    public void draw(Graphics2D g, Dimension canvasSize) {
        
        int baseSize = Math.min(canvasSize.width, canvasSize.height);

        //length of spaceship landing base
        int asteroidSize = baseSize / Global.SCALE; 
        
        //calculating x and y coordinate of planet
        int centerX = (int) (canvasSize.width / xOffset);
        int centerY = (int) (canvasSize.height / yOffset);
        int size_reducer = 3;
        
        //coordinates for asteroid object
        int[] xPoints = {
            centerX + asteroidSize / size_reducer,
            centerX + asteroidSize / size_reducer,
            centerX,
            centerX,
            centerX,
            centerX - asteroidSize / size_reducer,
            centerX - asteroidSize / size_reducer,
            centerX - asteroidSize / size_reducer,  
        };

        int[] yPoints = {
            
            centerY - asteroidSize / size_reducer,
            centerY,
            centerY,
            centerY,
            centerY,
            centerY + asteroidSize / size_reducer,
            centerY + asteroidSize / size_reducer,
            centerY - asteroidSize / size_reducer,
        };

        g.setColor(Color.gray);
        g.fillPolygon(xPoints, yPoints, 8);
        
    }

    /* updateLocation
     * parameters none
     * returns nothing
     * updates location of the planet on the map
    */
    public void updateLocation() {
        Random rand = new Random();

        double minX = 1.5;
        double maxX = 4.5;

        //limit values to be betwen minX and maxX
        xOffset =  minX + (maxX - minX) * rand.nextDouble();
        yOffset =  minX + (maxX - minX) * rand.nextDouble();
    }
}

//My map class that is incharge of handling elements in the map
class MyMap extends JPanel {
    private CircleCanvas circleCanvas; //circle boundary for map
    private SpaceShipCanvas spaceShipCanvas; //spaceship drawing class
    private PlanetCanvas planetCanvas;//planet drawing class
    private PointerCanvas pointerCanvas; //pointer hand drawing class
    private AsteroidCanvas asteroidCanvas;


    //timer variables
    private Timer timer;
    private Timer asteroidTimer;
    private Timer shipTimer;
    private Timer planetTimer;

    public MyMap() {
        //create drawings
        this.circleCanvas = new CircleCanvas();
        this.spaceShipCanvas = new SpaceShipCanvas();
        this.planetCanvas = new PlanetCanvas();
        this.pointerCanvas = new PointerCanvas();
        this.asteroidCanvas = new AsteroidCanvas();

        //initialize timers
        //timer updates drawing position upon expiration
        timer = new Timer(50, 
                                new PointerUpdateListener(pointerCanvas, this));
        asteroidTimer = new Timer(10000, e -> {
            asteroidCanvas.updateLocation();
            repaint();
        });

        planetTimer = new Timer(50000, e -> {
            planetCanvas.updateLocation();
            repaint();
        });

        shipTimer = new Timer(25000, e -> {
            spaceShipCanvas.updateLocation();
            repaint();
        });
        
    }

    //starts simulation by starting the timer
    public void start_simulation() {
        timer.start();
        asteroidTimer.start();
        planetTimer.start();
        shipTimer.start();
    }

    //stops simulation by stopping the timer
    public void stop_simulation() {
        timer.stop();
        asteroidTimer.stop();
        planetTimer.stop();
        shipTimer.stop();
    }

    /* Paintcomponent
     * parameters is graphics to draw with
     * returns nothing
    */
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D graphic_2d = (Graphics2D) g; //2d graphics for drawings

        //draw shapes using draw function in DrawingCanvas interface
        circleCanvas.draw(graphic_2d, getSize());
        spaceShipCanvas.draw(graphic_2d, getSize());
        planetCanvas.draw(graphic_2d, getSize());
        asteroidCanvas.draw(graphic_2d, getSize());
        pointerCanvas.draw(graphic_2d, getSize());
    }
}





